import { useState } from 'react';
import { formatoFecha, nombrePunto, soloDigitos } from '../lib/data.js';

const VACIO = { nombres: '', apellidos: '', telefono: '', comunidad: '', tipo: 'Salud', observaciones: '' };
const TIPOS = ['Salud', 'Documentación', 'Asistencia social', 'Orientación legal', 'Otro'];

export default function Registro({ registros, punto, direccion, onGuardar }) {
  const [cedula, setCedula] = useState('');
  const [estado, setEstado] = useState({ tipo: 'inicial' });
  const [form, setForm] = useState(VACIO);
  const [aviso, setAviso] = useState('');

  const habilitado = estado.tipo === 'libre';
  const cambiar = (campo) => (e) => setForm({ ...form, [campo]: e.target.value });

  function validar() {
    const c = soloDigitos(cedula);
    if (c.length < 6) return setEstado({ tipo: 'invalida' });
    const previo = registros.find((r) => r.cedula === c);
    setEstado(previo ? { tipo: 'duplicado', previo } : { tipo: 'libre' });
  }

  function registrar(e) {
    e.preventDefault();
    const c = soloDigitos(cedula);
    if (registros.some((r) => r.cedula === c)) return validar(); // equivale a la restricción UNIQUE
    onGuardar({ id: Date.now(), cedula: c, ...form, punto, direccion: direccion.trim() || 'Dirección', fecha: new Date().toISOString() });
    setCedula(''); setForm(VACIO); setEstado({ tipo: 'inicial' });
    setAviso('Beneficiario registrado correctamente.');
    setTimeout(() => setAviso(''), 2600);
  }

  return (
    <form className="tarjeta" onSubmit={registrar}>
      <h2>Registrar beneficiario</h2>
      <label htmlFor="cedula">Cédula / Documento de identidad *</label>
      <div className="en-linea">
        <input
          id="cedula" inputMode="numeric" placeholder="Ej. 12345678" autoComplete="off" value={cedula}
          onChange={(e) => { setCedula(e.target.value); setEstado({ tipo: 'inicial' }); }}
          onBlur={() => cedula.trim() && validar()}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); validar(); } }}
        />
        <button type="button" className="boton" onClick={validar}>Validar</button>
      </div>

      {estado.tipo === 'invalida' && <div className="aviso peligro" role="alert"><b>Cédula inválida</b>Ingrese al menos 6 dígitos.</div>}
      {estado.tipo === 'libre' && <div className="aviso ok"><b>✓ Cédula disponible</b>Complete los datos del beneficiario.</div>}
      {estado.tipo === 'duplicado' && (
        <div className="aviso peligro" role="alert">
          <b>⚠ Beneficiario ya registrado</b>
          La cédula {estado.previo.cedula} ({estado.previo.nombres} {estado.previo.apellidos}) fue atendida el {formatoFecha(estado.previo.fecha)} en {nombrePunto(estado.previo.punto)}. No se permite un nuevo registro.
        </div>
      )}

      <fieldset disabled={!habilitado}>
        <div className="fila">
          <label>Nombres<input value={form.nombres} onChange={cambiar('nombres')} required /></label>
          <label>Apellidos<input value={form.apellidos} onChange={cambiar('apellidos')} required /></label>
          <label>Teléfono<input inputMode="tel" value={form.telefono} onChange={cambiar('telefono')} /></label>
          <label>Comunidad / Sector<input value={form.comunidad} onChange={cambiar('comunidad')} /></label>
        </div>
        <label>Tipo de atención requerida
          <select value={form.tipo} onChange={cambiar('tipo')}>{TIPOS.map((t) => <option key={t}>{t}</option>)}</select>
        </label>
        <label>Observaciones<textarea rows="2" value={form.observaciones} onChange={cambiar('observaciones')} /></label>
        <p><button type="submit" className="boton">Registrar Beneficiario</button></p>
      </fieldset>

      {aviso && <div className="aviso ok aviso-flotante" role="status">{aviso}</div>}
    </form>
  );
}
