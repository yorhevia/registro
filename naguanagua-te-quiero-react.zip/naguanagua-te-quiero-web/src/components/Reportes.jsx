import { useMemo, useState } from 'react';
import { PUNTOS, diaLocal, formatoFecha, nombrePunto } from '../lib/data.js';
import { exportarPDF } from '../lib/pdf.js';

export default function Reportes({ registros, onReiniciar }) {
  const [desde, setDesde] = useState('');
  const [hasta, setHasta] = useState('');
  const [punto, setPunto] = useState('');

  const filas = useMemo(
    () => registros
      .filter((r) => (!desde || diaLocal(r.fecha) >= desde) && (!hasta || diaLocal(r.fecha) <= hasta) && (!punto || r.punto === Number(punto)))
      .sort((a, b) => b.fecha.localeCompare(a.fecha)),
    [registros, desde, hasta, punto]
  );

  return (
    <section className="tarjeta">
      <h2>Panel de supervisión</h2>
      <div className="fila">
        <label>Desde<input type="date" value={desde} onChange={(e) => setDesde(e.target.value)} /></label>
        <label>Hasta<input type="date" value={hasta} onChange={(e) => setHasta(e.target.value)} /></label>
      </div>
      <label>Punto Móvil
        <select value={punto} onChange={(e) => setPunto(e.target.value)}>
          <option value="">Consolidado general</option>
          {PUNTOS.map((p) => <option key={p.id} value={p.id}>{p.nombre}</option>)}
        </select>
      </label>

      <div className="resumen">
        <div><b>{filas.length}</b><span>Total atendidos</span></div>
        {PUNTOS.filter((p) => !punto || p.id === Number(punto)).map((p) => (
          <div key={p.id}><b>{filas.filter((r) => r.punto === p.id).length}</b><span>{p.nombre}</span></div>
        ))}
      </div>

      <p className="acciones">
        <button className="boton" onClick={() => exportarPDF({ registros: filas, desde, hasta, punto: punto && Number(punto) })}>Exportar a PDF</button>
        <button className="boton secundario" onClick={onReiniciar}>Reiniciar datos demo</button>
      </p>

      <div className="desplazable">
        <table>
          <thead><tr><th>Cédula</th><th>Nombre</th><th>Comunidad</th><th>Punto</th><th>Fecha</th></tr></thead>
          <tbody>
            {filas.length === 0 && <tr><td colSpan="5">Sin registros para este filtro.</td></tr>}
            {filas.map((r) => (
              <tr key={r.id}>
                <td>{r.cedula}</td><td>{r.nombres} {r.apellidos}</td><td>{r.comunidad}</td><td>{nombrePunto(r.punto)}</td><td>{formatoFecha(r.fecha)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
