import { useEffect, useState } from 'react';
import Registro from './components/Registro.jsx';
import Reportes from './components/Reportes.jsx';
import { PUNTOS, cargarRegistros, guardarRegistros, reiniciarEjemplo } from './lib/data.js';

export default function App() {
  const [vista, setVista] = useState('registro');
  const [direccion, setDireccion] = useState('Dirección 01');
  const [punto, setPunto] = useState(1);
  const [registros, setRegistros] = useState(cargarRegistros);

  useEffect(() => guardarRegistros(registros), [registros]);

  return (
    <>
      <header className="cabecera">
        <div>
          <h1>Naguanagua Te Quiero a la Web</h1>
          <p>Registro en campo · Municipio Naguanagua</p>
        </div>
        <img className="logo" src={`${import.meta.env.BASE_URL}logo.png`} alt="Logo Naguanagua Te Quiero" />
      </header>

      <main>
        <section className="tarjeta fila">
          <label>
            Dirección
            <input value={direccion} onChange={(e) => setDireccion(e.target.value)} />
          </label>
          <label>
            Punto Móvil activo
            <select value={punto} onChange={(e) => setPunto(Number(e.target.value))}>
              {PUNTOS.map((p) => <option key={p.id} value={p.id}>{p.nombre}</option>)}
            </select>
          </label>
        </section>

        <nav className="tabs">
          <button className={vista === 'registro' ? 'activa' : ''} onClick={() => setVista('registro')}>Registro</button>
          <button className={vista === 'reportes' ? 'activa' : ''} onClick={() => setVista('reportes')}>Reportes</button>
        </nav>

        {vista === 'registro' ? (
          <Registro registros={registros} punto={punto} direccion={direccion} onGuardar={(r) => setRegistros((prev) => [...prev, r])} />
        ) : (
          <Reportes registros={registros} onReiniciar={() => setRegistros(reiniciarEjemplo())} />
        )}
      </main>
    </>
  );
}
