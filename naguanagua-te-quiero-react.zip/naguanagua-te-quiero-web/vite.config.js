import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' permite servir la app desde cualquier ruta del servidor
export default defineConfig({ plugins: [react()], base: './' });
