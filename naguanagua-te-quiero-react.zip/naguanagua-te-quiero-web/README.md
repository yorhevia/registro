# Naguanagua Te Quiero a la Web

Aplicación React (Vite) para registrar beneficiarios en puntos móviles, validar cédulas duplicadas y exportar reportes en PDF.

## Estructura

```
src/
  App.jsx                 Cabecera, selección de Dirección y Punto Móvil, pestañas
  components/Registro.jsx Formulario con validación anti-duplicidad
  components/Reportes.jsx Filtros, resumen y tabla
  lib/data.js             Capa de datos (hoy usa localStorage; reemplazar por la API)
  lib/pdf.js              Generación del PDF oficial
public/logo.png           Logo institucional
```

## Ejecutar en local

```bash
npm install
npm run dev
```

## Generar la versión de producción

```bash
npm run build
```

Se crea la carpeta `dist/` con archivos estáticos (HTML, JS, CSS e imagen).

## Publicar en un servidor accesible por WireGuard

WireGuard es una VPN: crea el túnel privado, pero no aloja páginas. La app se sirve desde un servidor web (por ejemplo Nginx) dentro de ese túnel.

1. Copie `dist/` al servidor usando su IP de WireGuard (ejemplo `10.0.0.1`):

   ```bash
   scp -r dist/* usuario@10.0.0.1:/var/www/ntqw/
   ```

2. Configure Nginx para que escuche solo en la IP del túnel:

   ```nginx
   server {
       listen 10.0.0.1:80;
       root /var/www/ntqw;
       index index.html;
       location / { try_files $uri /index.html; }
   }
   ```

3. Recargue Nginx (`sudo nginx -t && sudo systemctl reload nginx`) y abra `http://10.0.0.1` desde un equipo conectado a la VPN.

## Antes de usarla en jornadas reales

Los datos de esta versión se guardan en el navegador de cada dispositivo, por lo que **no se comparten entre puntos móviles**. Para validar duplicados entre puntos hace falta una base de datos central (PostgreSQL) con `UNIQUE (cedula)` y una API; solo debe reemplazar las funciones de `src/lib/data.js`.
